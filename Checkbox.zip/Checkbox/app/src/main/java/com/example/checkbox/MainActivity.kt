package com.example.checkbox

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.checkbox.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var entradaNum1:EditText
    lateinit var entradaNum2:EditText
    lateinit var entradaNum3:EditText
    lateinit var resultado:TextView
    lateinit var checkNum1:CheckBox
    lateinit var checkNum2:CheckBox
    lateinit var checkNum3:CheckBox
    lateinit var btnSuma:RadioButton
    lateinit var btnResta:RadioButton
    lateinit var btnMulti:RadioButton
    lateinit var btnDividir:RadioButton
    lateinit var btnMayor:RadioButton
    lateinit var btnMenor:RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val enlace = ActivityMainBinding.inflate(layoutInflater)

        entradaNum1=enlace.ingreseNumero1
        entradaNum2=enlace.ingreseNumero2
        entradaNum3=enlace.ingreseNumero3
        resultado=enlace.textNumResultado
        checkNum1=enlace.checkBoxNum1
        checkNum2=enlace.checkBoxNum2
        checkNum3=enlace.checkBoxNum3
        btnSuma=enlace.radioSuma
        btnResta=enlace.radioResta
        btnMulti=enlace.radioMulti
        btnDividir=enlace.radioDivision
        btnMayor=enlace.radioMayor
        btnMenor=enlace.radioMenor

        setContentView(enlace.root)

        configurarListeners()
    }

    private fun configurarListeners() {
        val checkBoxes = listOf(checkNum1, checkNum2, checkNum3)
        val radioButtons = listOf(btnSuma, btnResta, btnMulti, btnDividir, btnMayor, btnMenor)

        // Listener para los CheckBox
        checkBoxes.forEach { checkBox ->
            checkBox.setOnCheckedChangeListener { _, _ ->
                validarYCalcular()
            }
        }

        // Listener para los RadioButton
        radioButtons.forEach { radioButton ->
            radioButton.setOnClickListener {
                validarYCalcular()
            }
        }
    }

    private fun validarYCalcular() {
        // Obtener los números seleccionados
        val numerosSeleccionados = mutableListOf<Double>()
        if (checkNum1.isChecked) numerosSeleccionados.add(entradaNum1.text.toString().toDoubleOrNull() ?: 0.0)
        if (checkNum2.isChecked) numerosSeleccionados.add(entradaNum2.text.toString().toDoubleOrNull() ?: 0.0)
        if (checkNum3.isChecked) numerosSeleccionados.add(entradaNum3.text.toString().toDoubleOrNull() ?: 0.0)

        // Validar que se hayan seleccionado exactamente dos números
        if (numerosSeleccionados.size != 2) {
            resultado.text = "Selecciona exactamente dos números"
            return
        }

        val num1 = numerosSeleccionados[0]
        val num2 = numerosSeleccionados[1]

        // Realizar la operación seleccionada
        when {
            btnSuma.isChecked -> resultado.text = "Resultado: ${num1 + num2}"
            btnResta.isChecked -> resultado.text = "Resultado: ${num1 - num2}"
            btnMulti.isChecked -> resultado.text = "Resultado: ${num1 * num2}"
            btnDividir.isChecked -> {
                if (num2 != 0.0) {
                    resultado.text = "Resultado: ${num1 / num2}"
                } else {
                    resultado.text = "Error: División por cero"
                }
            }
            btnMayor.isChecked -> resultado.text = "Mayor: ${maxOf(num1, num2)}"
            btnMenor.isChecked -> resultado.text = "Menor: ${minOf(num1, num2)}"
            else -> resultado.text = "Selecciona una operación"
        }
    }
}
