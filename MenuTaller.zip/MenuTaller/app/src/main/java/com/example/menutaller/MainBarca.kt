package com.example.menutaller

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutaller.databinding.ActivityMadridBinding
import com.example.menutaller.databinding.ActivityMainBarcaBinding

class MainBarca : AppCompatActivity() {
    lateinit var btnVolver: Button
    lateinit var btnCerrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val enlace3= ActivityMainBarcaBinding.inflate(layoutInflater)
        btnVolver=enlace3.btnVolverBarca
        btnCerrar=enlace3.btnCerrarBarca


        btnVolver.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnCerrar.setOnClickListener{view->
            cerrar(view)
        }

        setContentView(enlace3.root)

    }

    fun llamarVEntana (view: View){
        val op= Intent(this,MainActivity::class.java)
        startActivity(op)
    }

    fun cerrar(view: View){
        finish()
    }
}