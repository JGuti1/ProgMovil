package com.example.menutaller

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutaller.databinding.ActivityMadridBinding

class Madrid : AppCompatActivity() {

    lateinit var btnVolver: Button
    lateinit var btnCerrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val enlace2= ActivityMadridBinding.inflate(layoutInflater)
        btnVolver=enlace2.btnVolver
        btnCerrar=enlace2.btnCerrar


        btnVolver.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnCerrar.setOnClickListener{view->
            cerrar(view)
        }

        setContentView(enlace2.root)

    }

    fun llamarVEntana (view: View){
        val op= Intent(this,MainActivity::class.java)
        startActivity(op)
    }

    fun cerrar(view: View){
        finish()
    }
}