package com.example.menutaller

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutaller.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var btnMadrid:Button
    lateinit var btnUnited:Button
    lateinit var btnBarca:Button
    lateinit var btnBVB:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val enlace = ActivityMainBinding.inflate(layoutInflater)
        btnMadrid=enlace.btnMadrid
        btnUnited=enlace.btnUnited
        btnBarca=enlace.btnBarcelona
        btnBVB=enlace.btnBvb


        btnMadrid.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnUnited.setOnClickListener{view->
            llamarUnited(view)
        }

        btnBarca.setOnClickListener{view->
            llamarBarcelona(view)
        }

        btnBVB.setOnClickListener{view->
            llamarBVB(view)
        }


        setContentView(enlace.root)


        }

    fun llamarVEntana(view: View){
        val op= Intent(this,Madrid::class.java)
        startActivity(op)
    }

    fun llamarUnited(view: View){
        val op= Intent(this,MainUnited::class.java)
        startActivity(op)
    }

    fun llamarBarcelona(view: View){
        val op= Intent(this,MainBarca::class.java)
        startActivity(op)
    }

    fun llamarBVB(view: View){
        val op= Intent(this,MainBVB::class.java)
        startActivity(op)
    }

    }
