package com.example.bdtarea
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.bdtarea.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var botonEnviar: Button
    lateinit var consulta: TextView
    lateinit var placa: EditText
    lateinit var color: EditText
    lateinit var peso: EditText
    lateinit var marca: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val enlace = ActivityMainBinding.inflate(layoutInflater)

        botonEnviar = enlace.button
        consulta = enlace.consulta
        placa = enlace.placa
        color = enlace.color
        peso = enlace.peso
        marca = enlace.marca

        botonEnviar.setOnClickListener { view ->
            consultarServicio(view)
        }

        setContentView(enlace.root)
    }

    fun consultarServicio(view: View) {
        val url = "http://192.168.56.1/aplicacion/insertar.php"

        val queue = Volley.newRequestQueue(this)

        val postRequest = object : StringRequest(Method.POST, url,
            Response.Listener { response ->
                consulta.text = response.toString()
            },
            Response.ErrorListener { error ->
                consulta.text = "Error: ${error.message}"
            }
        ) {
            override fun getParams(): Map<String, String> {
                val params = HashMap<String, String>()
                params["placa"] = placa.text.toString()
                params["color"] = color.text.toString()
                params["peso"] = peso.text.toString()
                params["marca"] = marca.text.toString()
                return params
            }
        }

        queue.add(postRequest)
    }


}
