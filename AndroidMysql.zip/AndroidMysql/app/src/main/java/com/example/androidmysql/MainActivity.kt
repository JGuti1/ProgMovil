package com.example.androidmysql

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.androidmysql.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var botonEnviar:Button
    lateinit var consulta:TextView
    lateinit var nombre:TextView
    lateinit var correo:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val enlace = ActivityMainBinding.inflate(layoutInflater)
        botonEnviar = enlace.button
        consulta = enlace.consulta
        nombre = enlace.nombre
        correo= enlace.correo

        botonEnviar.setOnClickListener{view->
            consultarServicio(view)
        }

        setContentView(enlace.root)
    }

    fun consultarServicio(view: View){

        val url="http://172.16.9.184/aplicacion/insertar.php?nombre="+nombre.text.toString()+"&correo"+correo.text.toString()

       // val url="http://172.16.9.184/aplicacion/insertar.php"


        val cola= Volley.newRequestQueue(this);
        val cadenaConexion= StringRequest(
            Request.Method.GET,url,
            { response ->
                consulta.text=response.toString();
            },
            { consulta.text = "puede exitir un error" })
        cola.add(cadenaConexion)


    }




}

