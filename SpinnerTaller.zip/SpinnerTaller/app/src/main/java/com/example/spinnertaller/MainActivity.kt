package com.example.spinnertaller

import android.media.Image
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.spinnertaller.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var lista:Spinner
    lateinit var imagen:ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)

        lista= binding.spinner
        imagen= binding.imageView
        var opciones= listOf<String>("Ferrari","Lamborghini","Jaguar", "Maserati")

        val imagenes = listOf(
            R.drawable.ferrari,
            R.drawable.lamborghini,
            R.drawable.jaguar,
            R.drawable.maserati
        )

        val adaptador= ArrayAdapter(this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item,opciones)

        lista.adapter=adaptador
        lista.onItemSelectedListener = object:
            AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                //  TODO("Not yet implemented")
                imagen.setImageResource(imagenes[position])
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                //  TODO("Not yet implemented")
            }

        }

        setContentView(binding.root)

        }
    }
