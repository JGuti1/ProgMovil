package com.example.menutareas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutareas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var btnTarea1: Button
    lateinit var btnTarea2: Button
    lateinit var btnTarea3: Button
    lateinit var btnTarea4: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val enlace = ActivityMainBinding.inflate(layoutInflater)
        btnTarea1=enlace.btnTarea1
        btnTarea2=enlace.btnTarea2
        btnTarea3=enlace.btnTarea3
        btnTarea4=enlace.btnTarea4


        btnTarea1.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnTarea2.setOnClickListener{view->
            llamarRadio(view)
        }

        btnTarea3.setOnClickListener{view->
            llamarSuma(view)
        }

        btnTarea4.setOnClickListener{view->
            llamarBraille(view)
        }


        setContentView(enlace.root)


    }

    fun llamarVEntana(view: View){
        val op= Intent(this,MainDado::class.java)
        startActivity(op)
    }

    fun llamarRadio(view: View){
        val op= Intent(this,MainRadioButtons::class.java)
        startActivity(op)
    }

    fun llamarSuma(view: View){
        val op= Intent(this,MainSuma::class.java)
        startActivity(op)
    }

    fun llamarBraille(view: View){
        val op= Intent(this,MainBraille::class.java)
        startActivity(op)
    }

}