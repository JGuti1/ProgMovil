package com.example.menutareas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutareas.databinding.ActivityMainSumaBinding

class MainSuma : AppCompatActivity() {
    lateinit var imgNumero1: ImageView
    lateinit var imgNumero2: ImageView
    lateinit var imgResultado: ImageView
    lateinit var botonG: Button
    lateinit var btnVolver: Button
    lateinit var btnCerrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val enlace = ActivityMainSumaBinding.inflate(layoutInflater)

        imgNumero1=enlace.imgNumero1
        imgNumero2=enlace.imgNumero2
        imgResultado=enlace.imgResultado
        botonG=enlace.btngenerar
        btnVolver=enlace.btnVolver
        btnCerrar=enlace.btnCerrar


        setContentView(enlace.root)

        botonG.setOnClickListener{
                view->MostrarSuma(view)
        }

        btnVolver.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnCerrar.setOnClickListener{view->
            cerrar(view)
        }

    }

    fun GenerarNumero():Int{
        val numerorandom= (0..9).random()
        return  numerorandom
    }

    fun MostrarSuma(view: View){
        val valor1 = GenerarNumero()
        val valor2 = GenerarNumero()


        mostrarImagenNumero(imgNumero1, valor1)
        mostrarImagenNumero(imgNumero2, valor2)

        val suma = valor1 + valor2

        // Mostrar la imagen del resultado
        mostrarImagenNumero(imgResultado, suma)
    }

    fun mostrarImagenNumero(imageView: ImageView, numero: Int) {
        val imagenResId = when (numero) {
            0 -> R.drawable.cero
            1 -> R.drawable.uno1
            2 -> R.drawable.dos1
            3 -> R.drawable.tres1
            4 -> R.drawable.cuatro1
            5 -> R.drawable.cinco1
            6 -> R.drawable.seis1
            7 -> R.drawable.siete
            8 -> R.drawable.ocho
            9 -> R.drawable.nueve
            10 -> R.drawable.diez
            11 -> R.drawable.once
            12 -> R.drawable.doce
            13 -> R.drawable.trece
            14 -> R.drawable.catorce
            15 -> R.drawable.quince
            16 -> R.drawable.dieciseis
            17 -> R.drawable.diecisiete
            18 -> R.drawable.dieciocho
            else -> R.drawable.cero
        }
        imageView.setImageResource(imagenResId)
    }

    fun llamarVEntana (view: View){
        val op= Intent(this,MainActivity::class.java)
        startActivity(op)
    }

    fun cerrar(view: View){
        finish()
    }

}