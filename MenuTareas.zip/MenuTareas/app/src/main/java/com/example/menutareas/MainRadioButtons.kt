package com.example.menutareas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutareas.databinding.ActivityMainRadioButtonsBinding

class MainRadioButtons : AppCompatActivity() {
    lateinit var numero: ImageView
    lateinit var radio1: RadioButton
    lateinit var radio2: RadioButton
    lateinit var radio3: RadioButton
    lateinit var radio4: RadioButton
    lateinit var btnVolver: Button
    lateinit var btnCerrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val enlace = ActivityMainRadioButtonsBinding.inflate(layoutInflater)
        numero = enlace.imgCarro
        radio1 = enlace.radioBoton1
        radio2 = enlace.radioBoton2
        radio3 = enlace.radioBoton3
        radio4 = enlace.radioBoton4
        btnVolver=enlace.btnVolver
        btnCerrar=enlace.btnCerrar

        radio1.setOnClickListener { view ->
            cualRadioPResiono(view)
        }
        radio2.setOnClickListener { view ->
            cualRadioPResiono(view)
        }

        radio3.setOnClickListener { view ->
            cualRadioPResiono(view)
        }

        radio4.setOnClickListener { view ->
            cualRadioPResiono(view)
        }

        btnVolver.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnCerrar.setOnClickListener{view->
            cerrar(view)
        }

        setContentView(enlace.root)
    }

    fun cualRadioPResiono(view: View) {
        if (view is RadioButton) {
            if (view.id == R.id.radioBoton1) {
                numero.setImageResource(R.drawable.ferrari)
            }
            if (view.id == R.id.radioBoton2) {
                numero.setImageResource(R.drawable.lamborghini)
            }
            if (view.id == R.id.radioBoton3){
                numero.setImageResource(R.drawable.jaguar)
            }
            if (view.id == R.id.radioBoton4){
                numero.setImageResource(R.drawable.maserati)
            }


        }


    }

    fun llamarVEntana (view: View){
        val op= Intent(this,MainActivity::class.java)
        startActivity(op)
    }

    fun cerrar(view: View){
        finish()
    }
}