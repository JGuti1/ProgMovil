package com.example.menutareas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.menutareas.databinding.ActivityMainBrailleBinding

class MainBraille : AppCompatActivity() {
    lateinit var imagen: ImageView
    lateinit var letra: TextView
    lateinit var botonG: Button
    lateinit var btnVolver: Button
    lateinit var btnCerrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val enlace = ActivityMainBrailleBinding.inflate(layoutInflater)

        imagen=enlace.imgLetra
        letra=enlace.txtLetra
        botonG=enlace.btnGenerar
        btnVolver=enlace.btnVolver
        btnCerrar=enlace.btnCerrar

        setContentView(enlace.root)

        botonG.setOnClickListener{
                view->MostrarLetra(view)
        }

        btnVolver.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnCerrar.setOnClickListener{view->
            cerrar(view)
        }

    }

    fun GenerarLetra():Char{
        val letraAscii =(65..90).random()
        return letraAscii.toChar()
    }

    fun MostrarLetra(view: View){

        val valor1= GenerarLetra()
        letra.setText(valor1.toString())

        when(valor1){

            'A' -> imagen.setImageResource(R.drawable.a)
            'B' -> imagen.setImageResource(R.drawable.b)
            'C' -> imagen.setImageResource(R.drawable.c)
            'D' -> imagen.setImageResource(R.drawable.d)
            'E' -> imagen.setImageResource(R.drawable.e)
            'F' -> imagen.setImageResource(R.drawable.f)
            'G' -> imagen.setImageResource(R.drawable.g)
            'H' -> imagen.setImageResource(R.drawable.h)
            'I' -> imagen.setImageResource(R.drawable.i)
            'J' -> imagen.setImageResource(R.drawable.j)
            'K' -> imagen.setImageResource(R.drawable.k)
            'L' -> imagen.setImageResource(R.drawable.l)
            'M' -> imagen.setImageResource(R.drawable.m)
            'N' -> imagen.setImageResource(R.drawable.n)
            'O' -> imagen.setImageResource(R.drawable.o)
            'P' -> imagen.setImageResource(R.drawable.p)
            'Q' -> imagen.setImageResource(R.drawable.q)
            'R' -> imagen.setImageResource(R.drawable.r)
            'S' -> imagen.setImageResource(R.drawable.s)
            'T' -> imagen.setImageResource(R.drawable.t)
            'U' -> imagen.setImageResource(R.drawable.u)
            'V' -> imagen.setImageResource(R.drawable.v)
            'W' -> imagen.setImageResource(R.drawable.w)
            'X' -> imagen.setImageResource(R.drawable.x)
            'Y' -> imagen.setImageResource(R.drawable.y)
            'Z' -> imagen.setImageResource(R.drawable.z)

        }

    }

    fun llamarVEntana (view: View){
        val op= Intent(this,MainActivity::class.java)
        startActivity(op)
    }

    fun cerrar(view: View){
        finish()
    }

}