package com.example.menutareas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.menutareas.databinding.ActivityMainDadoBinding

class MainDado : AppCompatActivity() {
    lateinit var imagen1: ImageView
    lateinit var imagen2: ImageView
    lateinit var numero1: TextView
    lateinit var numero2: TextView
    lateinit var botonL: Button
    lateinit var txtgano: TextView
    lateinit var btnVolver: Button
    lateinit var btnCerrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val enlace = ActivityMainDadoBinding.inflate(layoutInflater)
        imagen1=enlace.imgDado1
        imagen2=enlace.imgDado2
        numero1=enlace.txtDado1
        numero2=enlace.txtDado2
        botonL=enlace.btnLanzar
        txtgano=enlace.txtGano
        btnVolver=enlace.btnVolver
        btnCerrar=enlace.btnCerrar



        botonL.setOnClickListener{
                view->mostrarDato(view)
        }

        btnVolver.setOnClickListener{view->
            llamarVEntana(view)
        }

        btnCerrar.setOnClickListener{view->
            cerrar(view)
        }

        setContentView(enlace.root)
    }

    fun LanzarDado():Int{
        val numero =(1..6).random()
        return numero
    }

    fun mostrarDato(view: View){
        val valor1 = LanzarDado()
        val valor2 = LanzarDado()
        numero1.setText(valor1.toString())
        numero2.setText(valor2.toString())

        when(valor1){
            1 -> imagen1.setImageResource(R.drawable.uno)
            2 -> imagen1.setImageResource(R.drawable.dos)
            3 -> imagen1.setImageResource(R.drawable.tres)
            4 -> imagen1.setImageResource(R.drawable.cuatro)
            5 -> imagen1.setImageResource(R.drawable.cinco)
            6 -> imagen1.setImageResource(R.drawable.seis)
        }

        when(valor2){
            1 -> imagen2.setImageResource(R.drawable.uno)
            2 -> imagen2.setImageResource(R.drawable.dos)
            3 -> imagen2.setImageResource(R.drawable.tres)
            4 -> imagen2.setImageResource(R.drawable.cuatro)
            5 -> imagen2.setImageResource(R.drawable.cinco)
            6 -> imagen2.setImageResource(R.drawable.seis)
        }

        if (valor1 + valor2 == 7){
            txtgano.setText("Saco 7 Gano")
        }
        else {
            txtgano.setText("Perdio")
        }
    }

    fun llamarVEntana (view: View){
        val op= Intent(this,MainActivity::class.java)
        startActivity(op)
    }

    fun cerrar(view: View){
        finish()
    }


}