package com.example.crud

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.crud.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var ed1: EditText// Mostrar los resultados en pantalla/Mapeo de campo de visualizaciòn
    lateinit var nombre:EditText
    lateinit var edad:EditText
    lateinit var mensaje: TextView
    lateinit var codigo:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        nombre=binding.Nombre
        edad=binding.Edad
        mensaje=binding.mensaje
        codigo=binding.Codigo
        setContentView(binding.root)
    }
    fun crearDatos(view: View){
        if(nombre.text.toString().length>0 && edad.text.toString().length>0){
            var usuario=
                Usuario(nombre.text.toString(),edad.text.toString().toInt())
            var Db= BaseDeDatos(this)
            mensaje.setText(Db.insertarDatos(usuario))
        }
    }
    fun leerDatos(view:View){
        var db= BaseDeDatos(this)
        var datos=db.traerDatos()
        mensaje.text=""
        for(i in 0..datos.size-1){
            val usuario =datos.get(i)
            mensaje.append("codigo:"+usuario.id +"Nombre: "+usuario.nombre+ " Edad "+usuario.edad+ "\n" )
        }
        db.close()
    }
    fun borrarDatos(view: View){
        var db=BaseDeDatos(this)
        db.borrar(codigo.text.toString())
    }
    fun actualizar(view: View){
        var db=BaseDeDatos(this)
        var usuario=
            Usuario(codigo.text.toString().toInt(),nombre.text.toString(),edad.text.toString().toInt())
        mensaje.setText(db.actualizar(usuario))
    }
}