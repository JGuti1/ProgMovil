package com.example.crud

class Usuario {
    var id:Int=0
    var nombre:String=""
    var edad :Int=0
    constructor(nombre:String,edad:Int){
        this.nombre=nombre
        this.edad=edad
    }
    //sobre carga de mètodos
    constructor(id:Int,nombre:String,edad:Int){
        this.nombre=nombre
        this.edad=edad
        this.id=id
    }
    constructor(){
    }
}
