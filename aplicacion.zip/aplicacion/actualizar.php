<?php
include 'conectar.php';

$correo=$_GET['correo'];
$nombre=$_GET['nombre'];




#preparé la instrucción de guardado
$sql = "UPDATE usuario set nombre=? where correo=?";

$comando= $pdo->prepare($sql);
$comando->execute([$nombre, $correo]);


?>
