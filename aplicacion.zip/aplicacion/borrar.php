<?php
include 'conectar.php';

$correo=$_GET['correo'];


#preparé la instrucción de guardado
$sql = "DELETE FROM usuario WHERE correo = ?";


$comando= $pdo->prepare($sql);
$comando->execute([$correo]);


?>