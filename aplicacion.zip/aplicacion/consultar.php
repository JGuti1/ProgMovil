<?php
include 'conectar.php';

#trear los registros tabla usuarios
$sql = "SELECT correo,clave,nombre FROM usuarios"; 
#ejecutar las conexiones a PDO
$query = $pdo -> prepare($sql); 
$query -> execute(); 

$consulta = $query -> fetchAll(PDO::FETCH_OBJ); 
echo "<table border=1>".$query -> rowCount();

if($query -> rowCount() > 0){ 
   foreach($consulta as $registro) { 
     echo "<tr>
     <td>".$registro -> correo."</td>
     <td>".$registro -> clave."</td>
     <td>".$registro -> nombre."</td>
     </tr>";
   }
   echo "</table>";
 }else{
 	echo "no existe datos";
 }
?>

