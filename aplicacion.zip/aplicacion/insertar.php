<?php
include 'conectar.php';

$correo=$_GET['correo'];
$nombre=$_GET['nombre'];

//$correo="vvierax@usc.edu.co";
//$nombre="victorx";


#preparé la instrucción de guardado
$sql = "INSERT INTO usuario (correo,nombre) VALUES (?,?)";

$comando= $pdo->prepare($sql);
$comando->execute([$correo,$nombre]);


?>
