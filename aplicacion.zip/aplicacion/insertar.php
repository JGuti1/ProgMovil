<?php
include 'conectar.php';

$placa = $_POST['placa'];
$color = $_POST['color'];
$peso = $_POST['peso'];
$marca = $_POST['marca'];

$sql = "INSERT INTO vehiculos (placa, color, peso, marca) VALUES (?, ?, ?, ?)";

$comando = $pdo->prepare($sql);
$comando->execute([$placa, $color, $peso, $marca]);

echo "Vehículo insertado correctamente";
?>
